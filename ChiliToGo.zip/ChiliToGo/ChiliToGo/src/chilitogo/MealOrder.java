
package chilitogo;


class MealOrder {
    private int numAdultMeals;
    private int numChildMeals;

    public void setNumAdultMeals(int numAdultMeals) {
        if (numAdultMeals >= 0) {
            this.numAdultMeals = numAdultMeals;
        } else {
            System.out.println("Invalid input. Please enter a non-negative integer.");
        }
    }

    public void setNumChildMeals(int numChildMeals) {
        if (numChildMeals >= 0) {
            this.numChildMeals = numChildMeals;
        } else {
            System.out.println("Invalid input. Please enter a non-negative integer.");
        }
    }

    public int getNumAdultMeals() {
        return numAdultMeals;
    }

    public int getNumChildMeals() {
        return numChildMeals;
    }
}

