
package chilitogo;

class PaymentMethod {
    public void choosePaymentMethod() {
        
System.out.print("\nChoose a payment method: ");
        System.out.println("\n1. Cash");
        System.out.println("2. Credit Card");
    }
}