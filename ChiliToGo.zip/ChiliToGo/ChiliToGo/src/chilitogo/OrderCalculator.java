
package chilitogo;

class OrderCalculator {
    private MealOrder mealOrder;

    public OrderCalculator(MealOrder mealOrder) {
        this.mealOrder = mealOrder;
    }

    public double calculateSubtotal() {
        return mealOrder.getNumAdultMeals() * 7 + mealOrder.getNumChildMeals() * 4;
    }

    public double calculateTax() {
        return calculateSubtotal() * 0.10;
    }

    public double calculateTotal() {
        return calculateSubtotal() + calculateTax();
    }

    public double calculateDiscount() {
        int totalMeals = mealOrder.getNumAdultMeals() + mealOrder.getNumChildMeals();
        if (totalMeals > 10) {
            return calculateTotal() * 0.10;
        }
        return 0;
    }
}