
package chilitogo;

class Menu {
    public void displayMenu() {
        
System.out.println("Menu:");
        System.out.println("1. Adult Meal = $7");
        System.out.println("2. Child Meal = $4");
    }
}