
package chilitogo;
import java.util.Scanner;

public class ChiliToGo {
public static void main(String[] args) {
        
 Scanner scanner = new Scanner(System.in);

        MealOrder mealOrder = new MealOrder();
        OrderCalculator orderCalculator = new OrderCalculator(mealOrder);
        Menu menu = new Menu();
        PaymentMethod paymentMethod = new PaymentMethod();

        System.out.println("Welcome to the Huntington Boys and Girls Club Meal Ordering System!");

        menu.displayMenu();

        System.out.print("Enter the number of adult meals ordered: ");
        int numAdultMeals = scanner.nextInt();
        mealOrder.setNumAdultMeals(numAdultMeals);

        System.out.print("Enter the number of child meals: ");
        int numChildMeals = scanner.nextInt();
        mealOrder.setNumChildMeals(numChildMeals);

        System.out.println("\nOrder Summary:");
        System.out.println("Number of Adult Meals: " + mealOrder.getNumAdultMeals());
        System.out.println("Number of Child Meals: " + mealOrder.getNumChildMeals());

        System.out.println("\nCalculating Total...");

        System.out.println("Subtotal: $" + orderCalculator.calculateSubtotal());
        System.out.println("Tax (10%): $" + orderCalculator.calculateTax());
        System.out.println("Discount: $" + orderCalculator.calculateDiscount());
        System.out.println("Total: $" + (orderCalculator.calculateTotal() - orderCalculator.calculateDiscount()));

        paymentMethod.choosePaymentMethod();
        
         var choosePaymentMethod = scanner.nextInt();
      
 System.out.print("Thank You! Payment successful ");
        scanner.close();
    }
}